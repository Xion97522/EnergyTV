export type MediaType = "movie" | "tv";

export interface Media {
  id: number;
  tmdbId: number;
  title: string;
  poster: string;
  backdrop: string;
  year: number;
  rating: number;
  type: MediaType;
  genres: string[];
  overview: string;
  duration?: string;
  seasons?: number;
  episodes?: Episode[];
  cast?: string[];
  realCast?: { id: number; name: string; character: string; photo: string }[];
  director?: string;
  quality?: string;
}

export interface Episode {
  season: number;
  episode: number;
  title: string;
  overview: string;
  duration: string;
  airDate: string;
}

const TMDB = "https://image.tmdb.org/t/p";

export const movies: Media[] = [
  { id: 693134, tmdbId: 693134, title: "Dune: Part Two", poster: `${TMDB}/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg`, backdrop: `${TMDB}/w1280/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg`, year: 2024, rating: 8.5, type: "movie", genres: ["Sci-Fi", "Adventure"], overview: "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.", duration: "2h 46m", quality: "4K" },
  { id: 872585, tmdbId: 872585, title: "Oppenheimer", poster: `${TMDB}/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg`, backdrop: `${TMDB}/w1280/rLb2cwF3Pazuxaj0sRXQ037tGI1.jpg`, year: 2023, rating: 8.3, type: "movie", genres: ["Biography", "Drama"], overview: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.", duration: "3h 0m", quality: "4K" },
  { id: 792307, tmdbId: 792307, title: "Poor Things", poster: `${TMDB}/w500/kCGlIMHnOm8JPXIf9fLwQBPSLKM.jpg`, backdrop: `${TMDB}/w1280/lOKHuVKjzPYNXi9S1EfbTU8Dq9q.jpg`, year: 2023, rating: 8.1, type: "movie", genres: ["Comedy", "Drama"], overview: "The incredible tale about the fantastical evolution of Bella Baxter.", duration: "2h 21m", quality: "HD" },
  { id: 466420, tmdbId: 466420, title: "Killers of the Flower Moon", poster: `${TMDB}/w500/dB6GNqeS72kiVzDFcFkxK8TrKEl.jpg`, backdrop: `${TMDB}/w1280/1X7vow16X7CnCojoRZZNNPHVObK.jpg`, year: 2023, rating: 7.8, type: "movie", genres: ["Crime", "Drama"], overview: "Members of the Osage Nation are murdered under mysterious circumstances in the 1920s.", duration: "3h 26m", quality: "4K" },
  { id: 940721, tmdbId: 940721, title: "Godzilla x Kong", poster: `${TMDB}/w500/tMefBSflR6PGQLv7WvFPpTKpYlk.jpg`, backdrop: `${TMDB}/w1280/4XM8DUTQb3lhLemJC51Jx4a2EuA.jpg`, year: 2024, rating: 7.0, type: "movie", genres: ["Action", "Sci-Fi"], overview: "The newly allied monsters must team up against a colossal undiscovered threat.", duration: "1h 55m", quality: "4K" },
  { id: 930564, tmdbId: 930564, title: "Saltburn", poster: `${TMDB}/w500/qitIXAaUoFPjh3FtxaIbV0e2cqo.jpg`, backdrop: `${TMDB}/w1280/qjVMoKLeT4DuqZqFJRSPrkFRtJb.jpg`, year: 2023, rating: 7.1, type: "movie", genres: ["Drama", "Thriller"], overview: "Struggling to find his place at Oxford, student Oliver Quick is drawn into the world of the charming Felix Catton.", duration: "2h 11m", quality: "HD" },
  { id: 977294, tmdbId: 977294, title: "Past Lives", poster: `${TMDB}/w500/k3waqVXSnkopSPlHDGKDQM1Tqbf.jpg`, backdrop: `${TMDB}/w1280/cKBKZKHfJfSaX9K0IPDkmFi5MXo.jpg`, year: 2023, rating: 7.9, type: "movie", genres: ["Drama", "Romance"], overview: "Two childhood friends are separated and then reunited over the span of 24 years.", duration: "1h 46m", quality: "HD" },
  { id: 1022789, tmdbId: 1022789, title: "Inside Out 2", poster: `${TMDB}/w500/vpnVM9B6NMmQpWeZvzLvDESb2QY.jpg`, backdrop: `${TMDB}/w1280/xg27NrXi7VXCGUr7MG75UqLl6Vg.jpg`, year: 2024, rating: 7.7, type: "movie", genres: ["Animation", "Comedy"], overview: "A new Emotion shows up in Riley's mind just as she's about to start high school.", duration: "1h 40m", quality: "4K" },
];

export const tvShows: Media[] = [
  { id: 100088, tmdbId: 100088, title: "The Last of Us", poster: `${TMDB}/w500/uKvVjHNqB5VmOrdxqAt2F7J78ED.jpg`, backdrop: `${TMDB}/w1280/uDgy6hyPd82kOHh6I95FLtLnj6p.jpg`, year: 2023, rating: 8.7, type: "tv", genres: ["Drama", "Horror"], overview: "Joel and Ellie must survive a journey across what remains of America.", seasons: 2, quality: "4K" },
  { id: 94997, tmdbId: 94997, title: "House of the Dragon", poster: `${TMDB}/w500/1X4h40fcB4WWUmIBK0auT4zRBAV.jpg`, backdrop: `${TMDB}/w1280/etj8E2o0Bud0HkONVQPjyCkIvpv.jpg`, year: 2022, rating: 8.4, type: "tv", genres: ["Action", "Fantasy"], overview: "The Targaryen dynasty is at the absolute peak of its power, with more than 15 dragons under their yoke.", seasons: 2, quality: "4K" },
  { id: 136315, tmdbId: 136315, title: "The Bear", poster: `${TMDB}/w500/sHFlbKS3WLqMnp9t2ghADIJFnuQ.jpg`, backdrop: `${TMDB}/w1280/mGVrXeIjyYBWcQLnE3lsewpDOzd.jpg`, year: 2022, rating: 8.6, type: "tv", genres: ["Comedy", "Drama"], overview: "A young chef from the fine dining world returns to Chicago to run his family's sandwich shop.", seasons: 3, quality: "HD" },
  { id: 126308, tmdbId: 126308, title: "Shogun", poster: `${TMDB}/w500/7O4iVfOMQmdCSxhOg1WnzG1AgYa.jpg`, backdrop: `${TMDB}/w1280/9bJFqPnGbDLjXv7bhFqGJuB0lNN.jpg`, year: 2024, rating: 8.6, type: "tv", genres: ["Action", "Drama"], overview: "A shipwrecked English navigator and a mysterious Christian Japanese lord become unlikely allies in feudal Japan.", seasons: 1, quality: "4K" },
  { id: 63174, tmdbId: 63174, title: "Succession", poster: `${TMDB}/w500/7HW47XbkNQ5fiwQFYGWdw9gs144.jpg`, backdrop: `${TMDB}/w1280/mDCBQNhR6R0PVFucJl973p4e9wB.jpg`, year: 2018, rating: 8.8, type: "tv", genres: ["Drama"], overview: "The Roy family, who controls one of the biggest media conglomerates, struggle for power.", seasons: 4, quality: "4K" },
  { id: 83867, tmdbId: 83867, title: "Andor", poster: `${TMDB}/w500/59SVNwLfoMnZPPB6ukW6dlPxAdI.jpg`, backdrop: `${TMDB}/w1280/4HodYYKEIsGOdinkGi2Ucz6X9i0.jpg`, year: 2022, rating: 8.3, type: "tv", genres: ["Sci-Fi", "Action"], overview: "The tale of the burgeoning rebellion against the Empire.", seasons: 2, quality: "4K" },
  { id: 95396, tmdbId: 95396, title: "Severance", poster: `${TMDB}/w500/lNxKr5kcSulVN4U5DgNJHhwUAMX.jpg`, backdrop: `${TMDB}/w1280/Aa5bPBbmDdIc96VNQpIxrIJn88E.jpg`, year: 2022, rating: 8.7, type: "tv", genres: ["Drama", "Mystery"], overview: "Mark leads a team of office workers whose memories have been surgically divided between work and personal life.", seasons: 2, quality: "4K" },
  { id: 202555, tmdbId: 202555, title: "True Detective: Night Country", poster: `${TMDB}/w500/h1vHwdBKnEAhYo0JbkMaeLLFvP5.jpg`, backdrop: `${TMDB}/w1280/p7yEqE45JnIfGfFZ6aUO4D79bHO.jpg`, year: 2024, rating: 7.7, type: "tv", genres: ["Crime", "Mystery"], overview: "When eight men who work at the Tsalal Arctic Research Station vanish, two detectives confront the darkness.", seasons: 1, quality: "HD" },
];

export const trending: Media[] = [movies[0], tvShows[0], movies[1], tvShows[3], movies[4], tvShows[2]];
export const topRated: Media[] = [tvShows[4], tvShows[6], tvShows[0], movies[1], tvShows[2], movies[2]];

export const categories = [
  { id: "trending", label: "Trending Now", items: trending },
  { id: "movies", label: "Popular Movies", items: movies },
  { id: "tv", label: "Top TV Shows", items: tvShows },
  { id: "toprated", label: "Top Rated", items: topRated },
];

export const allMedia: Media[] = [...movies, ...tvShows];

export function searchMedia(q: string): Media[] {
  const lq = q.toLowerCase();
  return allMedia.filter(
    (m) => m.title.toLowerCase().includes(lq) || m.genres.some((g) => g.toLowerCase().includes(lq)) || m.overview.toLowerCase().includes(lq)
  );
}

export function getMediaById(id: number): Media | undefined {
  return allMedia.find((m) => m.id === id);
}
